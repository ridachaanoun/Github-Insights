
let myflag = document.getElementById("flag");
let myprofile = document.getElementById("profile");
let myprofile_name= document.getElementById("name");
let mybio= document.getElementById("bio");
let myfollowers= document.getElementById("followers");
let myfollowing= document.getElementById("following");
let mypublicrepos= document.getElementById("mypublic-repos");
let memobers=document.getElementById("memobers")
let allrepos= document.getElementById("allrepos");
let toUp = document.getElementById("to-up");
let insights =document.getElementById("profile-insights");
let repos=[];
let object={};
let page2 =document.getElementById("page2");
page2.style.display='none';



const myHeaders = new Headers();
      myHeaders.append(
        "Authorization",
        "Bearer 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"
      );

      const requestOptions = {
        method: "GET",
        headers: myHeaders,
        redirect: "follow",
      };
    let username= document.getElementById("usernameInput").value;
        fetch(`https://api.github.com/users/ridachaanoun`, requestOptions)
          .then((response) => response.json())
          .then((myData) => { 
            const {
              login,
              avatar_url,
              bio,
              followers,
              following,
              public_repos,
              repos_url,
              location,
              created_at,
            } = myData; console.log(created_at)
             myprofile_name.innerText= login;
             mybio.innerText= bio;
             myprofile.src= avatar_url;
             myfollowers.innerText=followers;
             myfollowing.innerText=following;
             mypublicrepos.innerText= public_repos;
             memobers.innerText="5"

             fetch(repos_url, requestOptions)
             .then((response) => response.json())
             .then((reposData) => { 

             allrepos.innerHTML="";
             reposData.forEach((repo) => {
              
              let mincontainer =document.createDocumentFragment("div");
              let myDIv=document.createElement("div")
              let reponame = document.createElement("a");
              let public= document.createElement("span");
              let description= document.createElement("p");
              let languageDiv= document.createElement("div");
              let languagecolor=document.createElement("span");

              
              public.innerText="public"
              reponame.innerText=repo.name;

              mincontainer.appendChild(reponame)
              mincontainer.appendChild(public)
              
              description.innerText=repo.description
              languageDiv.innerText=repo.language
              languageDiv.appendChild(languagecolor)

              myDIv.appendChild(mincontainer)
              myDIv.appendChild(description)
              myDIv.appendChild(languageDiv)
              allrepos.appendChild(myDIv)

               myDIv.classList.add("bg-gray-400", "rounded-3xl", "flex","flex-col","justify-between",  "w-96" ,"gap-2" ,"pl-5","h-52")
               public.classList.add("border-solid","re", "w-20","rounded-xl","border-white","border-2","text-center");
          
               reponame.href=`https://github.com/ridachaanoun/${repo.name}`
              });
          fetch("https://api.github.com/emojis", requestOptions)
          .then((response) => response.json())
          .then((emojisData) => {
            // Extract the country from the location field
            const country = location.split(" ").pop().toLowerCase();
            const countryFlagUrl = emojisData[country];
            if (countryFlagUrl) {
              document.getElementById("flag").src = countryFlagUrl;
            } else {
              console.error(
                "Country flag not found for location:",
                location
              );
            }
          })
          .catch((error) =>
            console.error("Error fetching emojis data:", error)
          );
            })})
             .catch((error) =>
               console.error("Error fetching repositories data:", error)
             );
            //  search function

function getvalue(){
    let usernameInput =document.getElementById("usernameInput");
    let value = usernameInput.value;
    
            fetch(`https://api.github.com/users/${value}`, requestOptions)
            .then((response) => response.json())
            .then((userData) => {
              const {
                repos_url,
                public_repos,
              } = userData;//console.log(userData)
              allrepos.innerHTML="";
              page2.style.display='none';
              fetch(repos_url, requestOptions)
              .then((response) => response.json())
              .then((reposData) => { 
                allrepos.innerHTML="";
                
                // page 2
                insights.onclick= function(){
                   page2.style.display='';
                    console.log(repos);
                    let filteredArray = repos.filter(element => element !== null);
                    console.log(filteredArray);
                    for (let i of filteredArray) {
                        if (object[i]) {
                            object[i] += 1;
                        } else {
                            object[i] = 1;
                        }
                    }
                    console.log( object)


                    // Get an array of keys of the object

                     let keysArray = Object.keys(object);
                     let valueArray = Object.values(object);
                            console.log(valueArray)
                            console.log(keysArray)
                    // Get the length of the keys array, which equals the number of properties in the object
                    let length = keysArray.length;

                    // to add element to page 2
                        allrepos.innerHTML="";
                        let header =document.createElement("div");
                        header.innerHTML=  ` <h2> ${value} </h2>  <span> ergerger </span>    <span>not </span> ` 
                        let section=document.createElement("div")
                        let cardNumberOfRepos=document.createElement('span')
                        let numberUsedOflang=document.createElement('span')

                        cardNumberOfRepos.innerText=`number of repos is ${public_repos} `
                        numberUsedOflang.innerText=`number of language is ${length }`               
                                  

                        section.appendChild(cardNumberOfRepos)
                        section.appendChild(numberUsedOflang)
                        
                        allrepos.appendChild(header)
                        allrepos.appendChild(section)               

                        header.style.cssText="display: flex; width: 80% ;justify-content: space-between;height: 70px;align-items: center;border-radius: 15px; background-color: rgb(8 51 68 / var(--tw-bg-opacity));"
                        section.style.cssText="width: 80% ;justify-content: space-between;display: flex;gap: 5px; "
                        cardNumberOfRepos.style.cssText="width: 300px;height: 80px;display: flex;justify-content: center;align-items: center;border: solid;border-radius: 15px;"
                        numberUsedOflang.style.cssText="width: 300px;height: 80px;display: flex;justify-content: center;align-items: center;border: solid;border-radius: 15px;"
                        
                        const ctx = document.getElementById('myChart');

                        new Chart(ctx, {
                          type: 'bar',
                          data: {
                            labels:keysArray ,
                            datasets: [{
                              label:keysArray,
                              data: valueArray,
                              backgroundColor:["crimson","lightgreen","lightblue","violet","red"]
                              
                            }]
                          },
                          options: {
                            scales: {
                              y: {
                                suggestedMax:6,
                                ticks: {
                                    font:{
                                      size:30
                                    }
                                }
                              }
                            }
                          }
                        }
                        

                        
                        );
                      }
              repos=[];
               // to add elemets to section
                 reposData.forEach((repo) => {
                  let mincontainer =document.createDocumentFragment("div");
                  let myDIv=document.createElement("div")
                  let reponame = document.createElement('a');
                  let public= document.createElement('span');
                  let description= document.createElement("p");
                  let languageDiv= document.createElement("div");
                  let languagecolor=document.createElement("span");
                  
                  repos.push(repo.language);


                  public.innerText="public"
                  reponame.innerText=repo.name;

                  mincontainer.appendChild(reponame)
                  mincontainer.appendChild(public)
                      
                  description.innerText=repo.description
                  if(repo.description===null){
                    description.innerText="not description"
                  }

                  languageDiv.innerText=repo.language
                  languageDiv.appendChild(languagecolor)

                  myDIv.appendChild(mincontainer)
                  myDIv.appendChild(description)
                  myDIv.appendChild(languageDiv)
                  allrepos.appendChild(myDIv)

                   reponame.href=`https://github.com/${value}/${repo.name}`

                  myDIv.classList.add("bg-gray-400", "rounded-3xl", "flex","flex-col","justify-between",  "w-96" ,"gap-2" ,"pl-5","h-52")
                  public.classList.add("border-solid","re", "w-20","rounded-xl","border-white","border-2","text-center");
                  languagecolor.classList.add("bg-yellow-400","w-10","h-10");

                 });
             })
        })
      
      
      
      } 
toUp.onclick =function(){

  window.scrollTo({
    top:0,
    behavior:"smooth",
  });
};




